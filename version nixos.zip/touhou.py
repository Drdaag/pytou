from pictures import *
import time

print("\n" * 20)
while True :
    for k in liste:
        print(k, end="\033[61A")
        time.sleep(0.03)
        